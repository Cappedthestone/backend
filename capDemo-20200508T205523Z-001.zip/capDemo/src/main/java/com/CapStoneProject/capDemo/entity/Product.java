package com.CapStoneProject.capDemo.entity;

import java.text.DecimalFormat;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="products")
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="productId", nullable = false)
	private Integer productId;
	
	
	@OneToOne(fetch= FetchType.LAZY)
	@JoinColumn(name="productType", nullable=false)
	private Movies movie;
	
	@Column(name="productprice", nullable = false)
	private DecimalFormat productPrice =  new DecimalFormat("###,##");
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name= "orderId", nullable = false)
	private Order order;
	
	public Product() {
		
	}
	
	public Product(Integer productId, Movies movie, DecimalFormat productPrice, Order order) {
		this.productId = productId;
		this.movie = movie;
		this.productPrice = productPrice;
		this.order = order;
	}



	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	

	public Movies getMovie() {
		return movie;
	}

	public void setMovie(Movies movie) {
		this.movie = movie;
	}

	public DecimalFormat getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(DecimalFormat productPrice) {
		this.productPrice = productPrice;
	}
	
	

	public Order getOrder() {
		return order;
	}



	public void setOrder(Order order) {
		this.order = order;
	}



	@Override
	public String toString() {
		return "Product [productId=" + productId + ", movie=" + movie + ", productPrice=" + productPrice + ", order="
				+ order + "]";
	}



}
