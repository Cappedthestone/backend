package com.CapStoneProject.capDemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.CapStoneProject.capDemo.entity.Product;

@Controller
public class MovieController {
	
	@GetMapping("/movie")
	public String GetMovieList(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		return "movie";
	}
}
