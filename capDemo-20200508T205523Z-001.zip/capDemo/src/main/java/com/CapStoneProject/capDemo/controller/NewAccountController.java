package com.CapStoneProject.capDemo.controller;

import com.CapStoneProject.capDemo.entity.*;
import com.CapStoneProject.capDemo.service.UserService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
//@RequestMapping("/newAccount")
public class NewAccountController {
	
	
	@Autowired
	private UserService userService;
	
	public NewAccountController(UserService theUserService) {
		userService = theUserService;
	}
	
	@GetMapping("/newAccount")
	public String RegisterAccount(Model model) {
		User theUser = new User();
		model.addAttribute("user", theUser);
		
		return "newAccount";
	}
	
	
	@PostMapping("/newAccount/save")
	public String addUser(@ModelAttribute("user") User theUser, Model theModel) {
		
		String aUser = theUser.getEmail();
		Optional<User> oldUser = userService.findByUser(aUser);
		if (oldUser != null) {
			
			theModel.addAttribute("user", new User());
			
			return "newAccount";
		
		}
		
		userService.save(theUser);
		
		return "account";
		
	}

	
	
	

}
