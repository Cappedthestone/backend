package com.CapStoneProject.capDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.CapStoneProject.capDemo.entity.Movies;
import com.CapStoneProject.capDemo.entity.Product;
import com.CapStoneProject.capDemo.repository.ProductRepository;

public class ProductService {

	@Autowired
	ProductRepository productRepo;

	public ProductService(ProductRepository productRepo) {
		
		this.productRepo = productRepo;
	}
	
	public List<Product> findAll() {
		return	productRepo.findAll();
	}
	
	public Product findById(Integer id) {
		Optional<Product> result = productRepo.findById(id);
		
		Product product = null;
		
		if(result.isPresent()) {
			product = result.get();
		}  
		else {
			throw new RuntimeException("Cound not find product by that ID.");
		}
		
		return product;
		
		
	}
	
	
	public void save(Product product) {
		
		productRepo.save(product);	
	}
	
	public void deleteById(Integer id) {
		productRepo.deleteById(id);
	}

}
