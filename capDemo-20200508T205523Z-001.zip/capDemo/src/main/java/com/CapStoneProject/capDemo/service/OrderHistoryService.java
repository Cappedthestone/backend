package com.CapStoneProject.capDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.CapStoneProject.capDemo.entity.OrderHistory;
import com.CapStoneProject.capDemo.repository.OrderHistoryRepository;

public class OrderHistoryService {
	
	@Autowired
	OrderHistoryRepository orderhistoryRepo;

public List<OrderHistory> findAll() {
	
		return orderhistoryRepo.findAll();
	}
	
	public OrderHistory findById(Integer id) {
		
Optional<OrderHistory> result = orderhistoryRepo.findById(id);
		
		OrderHistory history = null;
		
		if(result.isPresent()) {
			history = result.get();
		}  
		else {
			throw new RuntimeException("Cound not find order history by that ID.");
		}
		
		return history;
	}
	
	
	public void save(OrderHistory history) {
		orderhistoryRepo.save(history);
	}
	
	public void deleteById(Integer id) {
		orderhistoryRepo.deleteById(id);
	}
}
