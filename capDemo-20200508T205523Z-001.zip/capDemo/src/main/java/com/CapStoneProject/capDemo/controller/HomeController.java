package com.CapStoneProject.capDemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value= {"/", "/home"})
public class HomeController {

	@GetMapping("")
	public String home() {
		
		return "home";
	}
	
	@GetMapping("/hello")
	public String hello() {
		
		
		return "hello";
	}
	
}
