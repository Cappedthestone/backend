package com.CapStoneProject.capDemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CapStoneProject.capDemo.entity.Movies;

@Repository
public interface MoviesRespository extends JpaRepository<Movies, Integer> {
	public Movies findByName(String name);
}
