package com.CapStoneProject.capDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.CapStoneProject.capDemo.entity.Role;
import com.CapStoneProject.capDemo.repository.RoleRepository;

public class RoleService {
	
	@Autowired
	private RoleRepository rolerepo;
	

	public RoleService(RoleRepository rolerepo) {
		this.rolerepo = rolerepo;
	}
	
	public List<Role> findAll() {
		return rolerepo.findAll();
	}
	
	public Role findById(Integer roleId) {
		Optional<Role> result = rolerepo.findById(roleId);
		Role role = null;
		
		if (result.isPresent()) {
			result.get();
		}else {
			throw new RuntimeException("Role ID not found");
		}
		
		return role;
	}
	
	public void save(Role role) {
		rolerepo.save(role);
	}
	
	public void deleteById(Integer id) {
		rolerepo.deleteById(id);
	}

}
