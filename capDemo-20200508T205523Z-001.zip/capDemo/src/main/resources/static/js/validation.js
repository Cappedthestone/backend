<script>
var email = document.getElementById("email");
function validation(){
    alert("Test");
    return false;
}
</script>