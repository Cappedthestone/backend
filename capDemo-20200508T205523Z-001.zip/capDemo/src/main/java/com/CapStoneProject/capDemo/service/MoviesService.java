package com.CapStoneProject.capDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.CapStoneProject.capDemo.entity.Movies;
import com.CapStoneProject.capDemo.entity.User;
import com.CapStoneProject.capDemo.repository.MoviesRespository;


public class MoviesService {
	
	@Autowired
	MoviesRespository movieRepo;
	
	

	public MoviesService(MoviesRespository movieRepo) {
	
		this.movieRepo = movieRepo;
	}

	public List<Movies> findAll() {
		return	movieRepo.findAll();
	}
	
	public Movies findById(Integer id) {
		Optional<Movies> result = movieRepo.findById(id);
		
		Movies movie = null;
		
		if(result.isPresent()) {
			movie = result.get();
		}  
		else {
			throw new RuntimeException("Cound not find user by that ID.");
		}
		
		return movie;
		
		
	}
	
	public Movies findByName(String movieName) {
		
		return movieRepo.findByName(movieName);
	}
	
	
	public void save(Movies movie) {
		
		movieRepo.save(movie);	
	}
	
	public void deleteById(Integer id) {
		movieRepo.deleteById(id);
	}
}
