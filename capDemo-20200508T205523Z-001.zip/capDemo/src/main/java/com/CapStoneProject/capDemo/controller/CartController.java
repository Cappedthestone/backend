package com.CapStoneProject.capDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.CapStoneProject.capDemo.repository.OrderRepository;

@Controller
public class CartController {
	
	@Autowired
	OrderRepository orderRepo;

	@GetMapping("/order")
	public String showOrder(Model model) {
		model.addAttribute("order", orderRepo.findAll());
		return "cart";
	}
}
