package com.CapStoneProject.capDemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

	@GetMapping("/account")
	public String account() {
		
		
		return "account";
	}
	
}
