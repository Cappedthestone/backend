package com.CapStoneProject.capDemo.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="orderid", nullable = false)
	private Integer orderId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name= "userId", nullable=false)
	private User users;
	
	@OneToMany(mappedBy= "order", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Set<Product> product;
	
	@OneToOne(mappedBy= "order", fetch=FetchType.LAZY, cascade=CascadeType.ALL)
	private OrderHistory orderHistory;
	
	public Order() {
		
	}
	


	public Order(Integer orderId, User users, Set<Product> product, OrderHistory orderHistory) {
		super();
		this.orderId = orderId;
		this.users = users;
		this.product = product;
		this.orderHistory = orderHistory;
	}


	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	
	public User getUsers() {
		return users;
	}

	public void setUsers(User users) {
		this.users = users;
	}

	public Set<Product> getProduct() {
		return product;
	}

	public void setProduct(Set<Product> product) {
		this.product = product;
	}



	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", users=" + users + ", product=" + product + ", orderHistory="
				+ orderHistory + "]";
	}

	
	
	

}
