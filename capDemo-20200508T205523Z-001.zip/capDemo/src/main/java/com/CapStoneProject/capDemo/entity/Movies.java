package com.CapStoneProject.capDemo.entity;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="movies")
public class Movies {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="movieid", nullable = false)
	private Integer mvoieId;
	
	@Column(name="movieName", nullable=false)
	private String name;
	
	@OneToOne(mappedBy="movie", fetch=FetchType.LAZY, cascade=CascadeType.ALL)
	private Product product;
	
	public Movies() {
		
	}
	
	public Movies(Integer mvoieId, String name, Product product) {
		super();
		this.mvoieId = mvoieId;
		this.name = name;
		this.product = product;
	}


	public Integer getMvoieId() {
		return mvoieId;
	}

	public void setMvoieId(Integer mvoieId) {
		this.mvoieId = mvoieId;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Movies [mvoieId=" + mvoieId + ", name=" + name + ", product=" + product + "]";
	}

	
	


}
