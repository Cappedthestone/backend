package com.CapStoneProject.capDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;


import com.CapStoneProject.capDemo.entity.Order;
import com.CapStoneProject.capDemo.repository.OrderRepository;

public class OrderService {
	
	@Autowired
	OrderRepository orderRepo;
	
	
	
	public OrderService(OrderRepository orderRepo) {
		
		this.orderRepo = orderRepo;
	}

	public List<Order> findAll() {
		return	orderRepo.findAll();
	}
	
	public Order findById(Integer id) {
		Optional<Order> result = orderRepo.findById(id);
		
		Order order = null;
		
		if(result.isPresent()) {
			order = result.get();
		}  
		else {
			throw new RuntimeException("Cound not find order by that ID.");
		}
		
		return order;
		
		
	}
	
	
	public void save(Order order) {
		
		orderRepo.save(order);	
	}
	
	public void deleteById(Integer id) {
		orderRepo.deleteById(id);
	}

}
