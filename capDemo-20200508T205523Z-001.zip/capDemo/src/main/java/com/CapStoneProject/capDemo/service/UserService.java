package com.CapStoneProject.capDemo.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.CapStoneProject.capDemo.entity.Role;
import com.CapStoneProject.capDemo.entity.User;
import com.CapStoneProject.capDemo.repository.RoleRepository;
import com.CapStoneProject.capDemo.repository.UserRepository;

//make sure to implement UserDetailsService later
@Service
public class UserService implements UserDetailsService{

	@Autowired
	private UserRepository theUserDao;
	
	@Autowired
	private RoleRepository roleRepository;
	
	String rolePrefix = "ROLE_";
	
	@Autowired
	public UserService(UserRepository theUserDao, RoleRepository theRoleRepository) {

		this.theUserDao = theUserDao;
		this.roleRepository = theRoleRepository;
	}
	
	
	public List<User> findAll() {
		return theUserDao.findAll();
	}
	
	public Optional<User> findByUser(String email) {
		
		return theUserDao.findByEmail(email);
	}
	
	public User findById(Integer id) {
		Optional<User> find =  theUserDao.findById(id);
		User newUser = null;
		
		if(find.isPresent()) {
			newUser = find.get();
		}  
		else {
			throw new RuntimeException("Cound not find user by that ID.");
		}
		
		return newUser;
	}
	
	public void save(User theUser) {
		User newUser = new User();
		
		Role role = roleRepository.findByRoleName(rolePrefix = "USER");
		Set<Role> roles = new HashSet<>();
		roles.add(role);
		theUser.setRole(roles);
		
		newUser.setEmail(theUser.getEmail());
		newUser.setFirstName(theUser.getFirstName());
		newUser.setLastName(theUser.getLastName());
		newUser.setPassword(theUser.getPassword());
		newUser.setRole(theUser.getRole());
		//newUser.setRole(Set<roleRepository.findRoleByName(rolePrefix + "USER")>);
		
		theUserDao.save(newUser);
	}
	
	public void deleteById(Integer id) {
		theUserDao.deleteById(id);
	}
	
	
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Optional<User> user = theUserDao.findByEmail(email);
		if (user==null) {
			throw new UsernameNotFoundException("Login not found.");
		}
		Set<GrantedAuthority> authorities = new HashSet<>();
		for(Role role : user.get().getRole()) {
			authorities.add(new SimpleGrantedAuthority(role.toString()));
		}
		return new org.springframework.security.core.userdetails.User(user.get().getEmail(), user.get().getPassword(), authorities);
	}
	

}
