package com.CapStoneProject.capDemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CapStoneProject.capDemo.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer>{

}
