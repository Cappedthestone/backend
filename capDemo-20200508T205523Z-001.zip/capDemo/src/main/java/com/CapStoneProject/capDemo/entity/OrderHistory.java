package com.CapStoneProject.capDemo.entity;

import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="orderHistory")
public class OrderHistory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="historyid", nullable = false)
	private Integer historyId;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="orderId", nullable=false)
	private Order order;
	
	@Column(name="orderdate")
	private Date date;
	
	public OrderHistory() {
		
	}
	

	public OrderHistory(Integer historyId, Order order, Date date) {

		this.historyId = historyId;
		this.order = order;
		this.date = date;
	}


	public Integer getHistoryId() {
		return historyId;
	}

	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}

	
	public Order getOrder() {
		return order;
	}


	public void setOrder(Order order) {
		this.order = order;
	}


	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}


	@Override
	public String toString() {
		return "OrderHistory [historyId=" + historyId + ", order=" + order + ", date=" + date + "]";
	}

	
	
}
